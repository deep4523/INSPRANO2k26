'use client';

import React, { useState, useEffect } from 'react';
import { Search, X, Award, ChevronRight } from 'lucide-react';

interface SearchModalProps {
  onClose: () => void;
  onSelectEvent: (event: any) => void;
}

export default function SearchModal({ onClose, onSelectEvent }: SearchModalProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<{ events: any[]; categories: any[]; sponsors: any[] }>({
    events: [],
    categories: [],
    sponsors: [],
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query.trim()) {
      setResults({ events: [], categories: [], sponsors: [] });
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const json = await res.json();
        if (json.success) {
          setResults(json.data);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-start justify-center pt-20 p-4">
      <div className="hud-panel cyber-clip w-full max-w-xl rounded-2xl border border-cyan-500/40 bg-slate-950 p-4 sm:p-6 shadow-[0_0_50px_rgba(0,210,255,0.3)]">
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 border-b border-cyan-500/20 pb-3">
          <Search className="w-5 h-5 text-cyan-400" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search events (e.g. Hackathon, EV, Mech, Civil)..."
            className="flex-1 bg-transparent text-sm sm:text-base text-white placeholder-slate-500 focus:outline-none font-sans"
          />
          <button
            onClick={onClose}
            aria-label="Close"
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results Container */}
        <div className="mt-4 max-h-[60vh] overflow-y-auto space-y-4">
          {loading && (
            <div className="py-8 text-center text-xs font-mono text-cyan-400 animate-pulse">
              Scanning festival database...
            </div>
          )}

          {!loading && query && results.events.length === 0 && results.categories.length === 0 && (
            <div className="py-8 text-center text-xs font-mono text-slate-400">
              No matching festival records found for "{query}".
            </div>
          )}

          {results.events.length > 0 && (
            <div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 mb-2">
                Events ({results.events.length})
              </div>
              <div className="space-y-1.5">
                {results.events.map((ev) => (
                  <div
                    key={ev.id}
                    onClick={() => {
                      onClose();
                      onSelectEvent(ev);
                    }}
                    className="p-2.5 rounded-xl bg-slate-900/60 hover:bg-cyan-950/40 border border-slate-800 hover:border-cyan-500/40 cursor-pointer flex items-center justify-between transition-colors group"
                  >
                    <div>
                      <div className="font-mech font-bold text-xs sm:text-sm text-slate-100 group-hover:text-cyan-300">
                        {ev.name}
                      </div>
                      <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                        {ev.department || 'General'} • Prize: ₹{ev.prize_amount.toLocaleString('en-IN')}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-cyan-400 transition-colors" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {results.categories.length > 0 && (
            <div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-blue-400 mb-2">
                Categories ({results.categories.length})
              </div>
              <div className="flex flex-wrap gap-2">
                {results.categories.map((cat) => (
                  <span
                    key={cat.id}
                    className="text-xs font-mech px-3 py-1 rounded-full bg-slate-900 border border-slate-700 text-slate-300"
                  >
                    {cat.name}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
