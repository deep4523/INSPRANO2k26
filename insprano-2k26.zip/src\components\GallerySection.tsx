'use client';

import React, { useState } from 'react';
import { Camera, Image as ImageIcon, X, ChevronLeft, ChevronRight } from 'lucide-react';

interface GalleryItem {
  id: number;
  title?: string;
  image_url: string;
  category?: string;
  caption?: string;
}

export default function GallerySection({ items = [] }: { items?: GalleryItem[] }) {
  const [activeImageIndex, setActiveImageIndex] = useState<number | null>(null);

  const defaultShowcase: GalleryItem[] = [];

  const galleryList = items.length > 0 ? items : defaultShowcase;

  const openLightbox = (index: number) => {
    setActiveImageIndex(index);
  };

  const closeLightbox = () => {
    setActiveImageIndex(null);
  };

  const nextImage = () => {
    if (activeImageIndex !== null) {
      setActiveImageIndex((activeImageIndex + 1) % galleryList.length);
    }
  };

  const prevImage = () => {
    if (activeImageIndex !== null) {
      setActiveImageIndex((activeImageIndex - 1 + galleryList.length) % galleryList.length);
    }
  };

  if (galleryList.length === 0) return null;

  return (
    <section id="gallery" className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-widest mb-3">
            <Camera className="w-3.5 h-3.5 text-cyan-400" />
            <span>FESTIVAL MEMORIES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black font-mech tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-100 to-cyan-300">
            GALLERY
          </h2>
          <p className="mt-1 text-sm text-slate-400 font-sans">
            Moments that inspire innovation and engineering excellence.
          </p>
        </div>

        <button
          onClick={() => {
            if (galleryList.length > 0) openLightbox(0);
          }}
          className="self-start sm:self-auto px-4 py-2 rounded-xl text-xs font-mech font-bold uppercase tracking-wider text-cyan-300 bg-slate-900/80 border border-cyan-500/30 hover:border-cyan-400 transition-colors"
        >
          View All Moments
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {galleryList.map((item, idx) => (
          <div
            key={item.id}
            onClick={() => openLightbox(idx)}
            className="group relative h-48 sm:h-56 rounded-2xl overflow-hidden cursor-pointer border border-cyan-500/20 hover:border-cyan-400 transition-all duration-300 bg-slate-900"
          >
            <img
              src={item.image_url}
              alt={item.title || 'INSPRANO Moment'}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80 group-hover:opacity-100"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-70 group-hover:opacity-90 transition-opacity" />

            <div className="absolute bottom-3 left-3 right-3">
              {item.category && (
                <span className="text-[9px] font-mech uppercase tracking-widest text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-500/30 inline-block mb-1">
                  {item.category}
                </span>
              )}
              <h4 className="text-xs sm:text-sm font-mech font-bold text-white line-clamp-1">
                {item.title}
              </h4>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {activeImageIndex !== null && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <button
            onClick={closeLightbox}
            aria-label="Close lightbox"
            className="absolute top-6 right-6 p-2 rounded-full bg-slate-800 text-slate-200 hover:text-white border border-slate-700"
          >
            <X className="w-6 h-6" />
          </button>

          <button
            onClick={prevImage}
            aria-label="Previous image"
            className="absolute left-4 sm:left-8 p-3 rounded-full bg-slate-900/80 text-cyan-400 hover:bg-slate-800 border border-cyan-500/30"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <div className="max-w-4xl max-h-[85vh] flex flex-col items-center">
            <img
              src={galleryList[activeImageIndex].image_url}
              alt={galleryList[activeImageIndex].title || 'Gallery image'}
              className="max-w-full max-h-[75vh] object-contain rounded-xl border border-cyan-500/40 shadow-[0_0_40px_rgba(0,210,255,0.4)]"
            />
            <div className="mt-3 text-center">
              <h3 className="font-mech font-bold text-base text-white">
                {galleryList[activeImageIndex].title}
              </h3>
              {galleryList[activeImageIndex].caption && (
                <p className="text-xs text-slate-400 mt-1">
                  {galleryList[activeImageIndex].caption}
                </p>
              )}
            </div>
          </div>

          <button
            onClick={nextImage}
            aria-label="Next image"
            className="absolute right-4 sm:right-8 p-3 rounded-full bg-slate-900/80 text-cyan-400 hover:bg-slate-800 border border-cyan-500/30"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      )}
    </section>
  );
}
