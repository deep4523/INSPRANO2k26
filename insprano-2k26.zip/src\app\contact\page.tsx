'use client';

import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { ArrowLeft, Mail, Phone, MapPin, Send, CheckCircle, MessageSquare } from 'lucide-react';

export default function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone, subject, message }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to submit contact message.');
      }

      setSuccess(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-950 text-white relative">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-cyan-400 transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Festival Portal</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Contact Details Side */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 bg-cyan-950/80 px-3 py-1 rounded-full border border-cyan-500/40 inline-block mb-3">
                DIRECT COMMUNICATOR
              </span>
              <h1 className="text-3xl sm:text-4xl font-black font-mech text-white">
                CONTACT ORGANIZERS
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 font-sans mt-2 leading-relaxed">
                Connect directly with the INSPRANO 2K26 coordination council at Government College of Engineering Kalahandi.
              </p>
            </div>

            <div className="space-y-4">
              <div className="hud-panel p-4 rounded-xl border border-slate-800 flex items-start gap-3">
                <MapPin className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                <div className="text-xs font-sans text-slate-300">
                  <strong className="block text-white font-mech mb-0.5">Campus Venue</strong>
                  Government College of Engineering Kalahandi, Bandopala, Bhawanipatna, Odisha — 766002
                </div>
              </div>

              <div className="hud-panel p-4 rounded-xl border border-slate-800 flex items-center gap-3">
                <Mail className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                <div className="text-xs font-mono text-slate-300">
                  <strong className="block text-white font-mech mb-0.5">Official Inquiries</strong>
                  <a href="mailto:insprano2026.gcek@gmail.com" className="text-cyan-400 hover:underline">
                    insprano2026.gcek@gmail.com
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="lg:col-span-7">
            <div className="hud-panel cyber-clip rounded-3xl p-6 sm:p-8 border border-cyan-500/30">
              {success ? (
                <div className="text-center py-10 space-y-3">
                  <div className="inline-flex p-3 rounded-full bg-emerald-500/10 border border-emerald-500/40 text-emerald-400">
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-black font-mech text-white">
                    MESSAGE TRANSMITTED
                  </h3>
                  <p className="text-xs text-slate-300 font-sans max-w-sm mx-auto">
                    Your inquiry has been stored in our communications database. A coordinator will reply to your email promptly.
                  </p>
                  <button
                    onClick={() => {
                      setSuccess(false);
                      setName('');
                      setEmail('');
                      setPhone('');
                      setSubject('');
                      setMessage('');
                    }}
                    className="mt-4 px-6 py-2 rounded-xl text-xs font-mech font-bold uppercase text-white bg-slate-800 hover:bg-slate-700"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <h2 className="font-mech font-bold text-lg text-white mb-2">
                    SEND INQUIRY OR ASSISTANCE REQUEST
                  </h2>

                  {error && (
                    <div className="p-3 rounded-lg bg-red-950/80 border border-red-500/50 text-red-200 text-xs font-mono">
                      {error}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">Your Name *</label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Full Name"
                        className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-400 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">Email Address *</label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="yourname@gmail.com"
                        className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-400 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">Phone Number</label>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+91..."
                        className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-400 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-none font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">Subject *</label>
                      <input
                        type="text"
                        required
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        placeholder="e.g. Accommodations / Hackathon query"
                        className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-400 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">Message *</label>
                    <textarea
                      required
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Enter your detailed inquiry..."
                      className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-400 rounded-xl p-3.5 text-xs sm:text-sm text-white focus:outline-none font-sans"
                    />
                  </div>

                  <div className="pt-2 text-right">
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-6 py-2.5 rounded-xl font-mech font-bold text-xs uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 shadow-[0_0_15px_rgba(0,210,255,0.4)] border border-cyan-400/50 disabled:opacity-50 flex items-center justify-center gap-2 ml-auto"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{loading ? 'Transmitting...' : 'Send Message'}</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  );
}
