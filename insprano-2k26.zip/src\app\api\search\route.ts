import { NextResponse } from 'next/server';
import { INITIAL_EVENTS } from '@/lib/db';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const query = (searchParams.get('q') || '').toLowerCase();
  
  if (!query) {
    return NextResponse.json({ success: true, data: [] });
  }

  const results = INITIAL_EVENTS.filter(
    e => e.name.toLowerCase().includes(query) || e.department.toLowerCase().includes(query)
  );

  return NextResponse.json({ success: true, data: results });
}
