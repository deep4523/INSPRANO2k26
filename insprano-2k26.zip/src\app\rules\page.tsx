'use client';

import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { ArrowLeft, ShieldCheck, AlertCircle, FileText, CheckCircle } from 'lucide-react';

export default function RulesPage() {
  const sections = [
    {
      title: 'General Code of Conduct',
      icon: ShieldCheck,
      rules: [
        'All participants must carry their valid Institutional ID Card and digital INSPRANO 2K26 Registration Pass at all times.',
        'Professional ethics, sportsman spirit, and mutual respect among colleges are strictly mandated.',
        'Any damage to campus property or laboratory equipment will result in immediate disqualification and liability.',
        'The decisions rendered by official jury panels and faculty judges are final and binding across all competitive categories.',
      ],
    },
    {
      title: 'Registration & Eligibility Guidelines',
      icon: CheckCircle,
      rules: [
        'Undergraduate and postgraduate students enrolled in recognized AICTE / UGC engineering or technical institutions are eligible.',
        'School Students category events are strictly reserved for students from recognized secondary schools (Class 8 — 12).',
        'Cross-college teams are permitted for designated open challenges such as the 24-Hour Hackathon, EV Working Model Challenge, and Esports championships.',
        'One participant can register for multiple events, provided event schedules do not conflict.',
      ],
    },
    {
      title: 'Technical Submissions & Intellectual Property',
      icon: FileText,
      rules: [
        'All hackathon code, prototypes, and engineering working models must be conceived and created in accordance with challenge timelines.',
        'Plagiarism or submission of pre-built commercial software without proper attribution will cause instantaneous disqualification.',
        'Open source libraries, hardware components, and frameworks must be clearly declared during preliminary technical evaluation.',
      ],
    },
    {
      title: 'Campus & Venue Regulations',
      icon: AlertCircle,
      rules: [
        'Government College of Engineering Kalahandi is a strictly tobacco-free, alcohol-free, and substance-free institution.',
        'Participants must adhere to designated entry/exit zones and lab safety safety protocols, specifically inside heavy machinery and electrical test benches.',
        'Organizers reserve the right to alter schedules or venues in case of logistical or meteorological necessities.',
      ],
    },
  ];

  return (
    <main className="min-h-screen bg-slate-950 text-white relative">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-xs font-mono text-slate-400 hover:text-cyan-400 transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Festival Portal</span>
        </Link>

        <div className="text-center mb-10">
          <span className="text-xs font-mono uppercase tracking-widest text-cyan-400 bg-cyan-950/80 px-3 py-1 rounded-full border border-cyan-500/40 inline-block mb-3">
            OFFICIAL POLICY & FRAMEWORK
          </span>
          <h1 className="text-3xl sm:text-5xl font-black font-mech tracking-wider text-white">
            RULES & REGULATIONS
          </h1>
          <p className="text-sm text-slate-400 font-sans mt-2 max-w-xl mx-auto">
            Governing rules, institutional eligibility criteria, and fair-play regulations for INSPRANO 2K26.
          </p>
        </div>

        <div className="space-y-6">
          {sections.map((sec, idx) => {
            const Icon = sec.icon;
            return (
              <div key={idx} className="hud-panel p-6 sm:p-8 rounded-2xl border border-slate-800">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h2 className="font-mech font-bold text-lg text-white">
                    {sec.title}
                  </h2>
                </div>

                <ul className="space-y-3">
                  {sec.rules.map((r, rIdx) => (
                    <li key={rIdx} className="flex items-start gap-2.5 text-xs sm:text-sm font-sans text-slate-300 leading-relaxed">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-2 flex-shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>

      <Footer />
    </main>
  );
}
